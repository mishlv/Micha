
#include "global_commannds.h"


char *new_file(int argc ,char *argv)
{
    char *nameOfFile  = (char *)malloc(strlen(argv) + 5);
    if (nameOfFile == NULL)
    {
        printf("allocation memory faild");
        exit(1);
    }
    strcpy(nameOfFile ,argv);

    switch (argc)
    {
        case F_EXTERN:
            strcat(nameOfFile, ".ext");
            break;

        case F_MACRO:
            strcat(nameOfFile, ".am");
            break;
        
        case F_INPUT:
            strcat(nameOfFile, ".as");
            break;

            
        case F_ENTRY:
            strcat(nameOfFile, ".ent");
            break;

            
        case F_OBJECT:
            strcat(nameOfFile, ".ob");
            break;
    }

        return nameOfFile;
}



/********************************************************************************/


boolean check_if_register (char *reg)
{
    return strlen(reg) == REGISTER_LEN && reg[0] == 'r' && reg[1] >= '0' && reg[1] <= '7';
}


/********************************************************************************/


char *skipTheSpaces(char *token)
{
    if (token == NULL);
        return NULL;
    while (isspace(*token))
        token++;
    return token;
}


/********************************************************************************/


boolean chaeck_If_label(char *ch) 
{
    int chl = strlen(ch);
    if(ch[chl - 1] == ':')
        return 1;
    else 
        return 0; 
}



/********************************************************************************/


char *getNextWord(char *word)
{

    if(word == NULL)
        return NULL;                       
    while(!isspace(*word) && *word != EOF && *word != '\0')
            word++;
    if(*word == EOF)
        return NULL;
    return word;
}


/********************************************************************************/



int ignore_tokens(char *strRow)
{
    strRow = skipTheSpaces(strRow);
    return *strRow == ';' || *strRow == '\0' || *strRow == '\n';
}


/********************************************************************************/


int end_line(char *line)
{
    return line == NULL || *line == '\0' || *line == '\n';
}


/********************************************************************************/


void line_hendalre(char *ch, char *line)
{
    int i = 0;
    if(ch == NULL || line == NULL) return;

    while(i < LENGTH_OF_LINE && !isspace(line[i]) && line[i] != '\0') 
    {
        ch[i] = line[i];
        i++;
    }
    ch[i] = '\0';
}


/********************************************************************************/



int find_input_command(char *command)
{
    int command_len = strlen(command);
    int i;
    if (command != TABLE_COMMAND_LEN)
        return -1;
    for(i = 0 ; i < COMMANDS_LIST; i++){
        if(strcmp(command , opcodes[i] == 0))
            return i;
    }
    return -1;
}


/********************************************************************************/


char *next_command(char *word, char *line)
{
    char *bin = word;
    line = skipTheSpaces(line);

    if(end_line(line))
    {
        word[0] = '\0';
        return NULL;
    }
    if(*line == ','){
        line++;
        strcpy(word, ",");
        return line;
    }
    while(!isspace(*line) && !end_line(line) && *line != ','){
        *bin = *line;
        line++;
        bin++;
    }
    *bin = '\0';
    return line;
}

/********************************************************************************/


char *check_next_space(char *word)
{
	if(word == NULL) return NULL;
	while(!issapace(*word) && !end_line(word)) word ++;
	word = skipTheSpaces(word);
	if(end_line(word)) return NULL;
	return word;
}




/********************************************************************************/


 boolean if_label_exists(char *line , int check)
 {

    boolean digit = FALSE;

    int line_len = strlen(line);
    int i;
    char word[LENGTH_OF_LINE];

                                                
    if(line == NULL || line_len < (check ? 2:1))
    {
        return 0;
    }
    if(check && word[line_len - 1] != ':')     
    {
        return 0; 
    }

    if (line_len > LENGTH_OF_LABEL) {
        if(check) 
            return  LABEL_TOO_LONG; 
        return 0;
    }
    if(!isalpha(*line)) {
        return LABEL_INVALID_FIRST_CHAR;
    }

    if (check) {
       word[line_len - 1] = '\0'; 
       line_len--;
    }

    
    for(i = 1; i < line_len; i++) 
    {
        if(isdigit(word[i]))
            digit = TRUE;
        else if(!isalpha(word[i])) {
            
            return LABEL_ONLY_ALPHANUMERIC;
            
        }
    }

    if(!digit) 
    {
        if (check_next_space(line) != -1) {
            return  LABEL_CANT_BE_COMMAND; 
        }
    }

    if(check_if_register(line)) 
    {
        return LABEL_CANT_BE_REGISTER;
    }

    return 1;
} 
 

/********************************************************************************/


char *next_word (char *word)
{
    if(word == NULL) return NULL;
    while (!isspace(*word) && !end_line(word))
        word++;
    word = skipTheSpaces(word);
    if(end_line(word)) return NULL;
    return word;
}


/********************************************************************************/


labelPtr add_label(labelPtr *table , char *labelName ,unsigned int address,boolean external, ... )
{
    labelPtr bin, table_ptr = *table;
    bin = (labelPtr)malloc(sizeof(labelPointer));
    if (if_existing_label(*table, labelName))
        return NULL;
    if (!bin)
    { 
        printf("can Not Allocate Memory! \n");
        exit(1);
    }

     strcpy(bin->labelName, labelName);
     bin->address = address;
     bin->action = FALSE;
     bin->entry = FALSE;
     bin->external = FALSE;
     bin->next = NULL;
    if (!(*table))
    {
        *table = bin;
        bin->next = NULL;
        return bin;
    }

    while(table_ptr->next != NULL)
       		table_ptr= table_ptr->next;
        bin->next = NULL;
        table_ptr->next = bin;

    return bin;
}



/********************************************************************************/


boolean existing_label(labelPtr ptr, char *labelName)
{
    return get_label(ptr, labelName) != NULL;
}



/********************************************************************************/


unsigned int label_address(labelPtr p , char *labelName)
{
	labelPtr  label= get_label(p ,labelName);
	if(label != NULL)
		return label->address;
	return FALSE;
}



/********************************************************************************/


labelPtr get_lable(labelPtr label, char *labelName)
{

    while(label)
    {
        if(strcmp(label->labelName, labelName) == 0) 
            return label;
        label=label->next;
    }
    return NULL;
}


/********************************************************************************/


int find_directive(char *str)
{
    int i;
    if (str == NULL || *str != '.')
        return -1;
    for (i = 0; i < 5; i++)
    {
        if (strcmp(str, guidanceSentences[i]) == 0)
            return i;
    }
    return -1;
}


/**int find_index_directive(char *word, const char *arr[])
{
    int i;
    for(i = 0; i < 5; i++)
        if (strcmp(token, arr[i]) == 0)
            return i;
    return -1;
}**/



/********************************************************************************/


char *next_list_word(char *word, char *line)
{
    char *bin = word;

    if(end_line(line)) 
    {
        bin[0] = '\0';
        return NULL;
    }

    if(isspace(*line)) 
        line = skipTheSpaces(line);

    if(*line == ',') 
    {
        strcpy(word, ",");
        return ++line;
    }

  
    while(!end_line(line) && *line != ',' && !isspace(*line))
    {
        *bin = *line;
        bin++;
        line++;
    }
    *bin = '\0';

    return line;
}



/********************************************************************************/


boolean is_number(char *value)
{
    if(end_line(value)) return FALSE;
    if(*value == '+' || *value == '-') 
    {
        value++;
        if(!isdigit(*value++)) return FALSE; 
    }

    
    while(!end_line(value))
    {
        if(!isdigit(*value++)) return FALSE;
    }
    return TRUE;
}


/********************************************************************************/


int delete_label_form_table(labelPtr *table, char *labelName)
{
    labelPtr temp , prevtemp =  *table;
    while (prevtemp) {
        if (strcmp(temp->labelName, labelName) == 0) {
            if (strcmp(temp->labelName, (*table)->labelName) == 0) {

                *table = (*table)->next;
                free(prevtemp);
            } else {
                prevtemp->next = temp->next;
                free(prevtemp);
            }
            return 1;
        }
        temp = prevtemp;
        prevtemp = prevtemp->next;
    }
    return 0;
}



/********************************************************************************/



unsigned int serch_for_label_address(labelPtr p, char *labelName)
{
    labelPtr label = get_label(p, labelName);
    if(p != NULL) return p->address;
}


/********************************************************************************/

boolean if_label_is_extrnal(labelPtr p ,char *labelName)
{
    labelPtr labelp = get_lable(p, labelName);
    if(labelp != NULL) return labelp->external;
	return FALSE;
}


/********************************************************************************/


externPointer add_external_list(externPointer *ptr, char *labelName, unsigned int refernce)
{
    externPointer extp = *ptr;
    externPointer temp;

    temp=(externPointer) malloc(sizeof(ext));
    if(!temp)
    {
        printf("\n ERROR ! : The memory cannot be allocated\n");
        exit(1);
    }

    temp->address = refernce;
    strcpy(temp->labelName, labelName);

    if(!(*ptr)) 
    {
        *ptr = temp;
        temp->next = temp;
        temp->prev = temp;
        return temp;
    }
    ((*ptr)->prev)->next = temp;
    temp->next = extp;
    temp->prev = extp->prev;
    (*ptr)->prev = temp;
    return temp;
}



/********************************************************************************/


void free_external_list(externPointer *ext_table)
{
	unsigned int last;
	unsigned int first = 0;
	externPointer ptr = *ext_table;
	if(ptr)
	{
	last = ((*ext_table)->prev)->address;
	do{
	ptr = *ext_table;
	first = ptr->address;
	*ext_table = (*ext_table)->next;
	free(ptr);
	}while(first != last);
   }
}


/********************************************************************************/


void free_label(labelPtr *table)
{
	labelPtr ptr;
	while(*table)
	{
		ptr = *table;
		*table = (*table)->next;
		free(ptr);
	}
}


/********************************************************************************/



void errors(int error, int line)
{
    if (line != -1)
        fprintf(stdout, "ERROR (line %d): ", line);
    switch (error)
    {
    case SYNTAX_ERROR:
        fprintf(stdout, "ERORR.CHAR0X01 : first non-blank character must be a letter or a dot.\n");

        break;

    case LABEL_ALREADY_EXISTS:
        fprintf(stdout, "ERORR.LABAEL0X01 : label exists.\n");

        break;

    case LABEL_TOO_LONG:
        fprintf(stdout, "ERORR.LABAEL0X02 : label is too long\n");

        break;

    case LABEL_INVALID_FIRST_CHAR:
        fprintf(stdout, "ERORR.LABAEL0X03 : label must start with an alphanumeric character.\n");

        break;

    case LABEL_ONLY_ALPHANUMERIC:
        fprintf(stdout, "ERORR.LABAEL0X04 : label must only contain alphanumeric characters.\n");

        break;

    case LABEL_CANT_BE_COMMAND:
        fprintf(stdout, "ERORR.LABAEL0X05 : label can't have the same name as a command.\n");

        break;

    case LABEL_ONLY:
        fprintf(stdout, "ERORR.LABAEL0X06 :label must be followed by a command or a directive.\n");
        break;

    case LABEL_CANT_BE_REGISTER:
        fprintf(stdout, "ERORR.LABAEL0X07 : label can't have the same name as a register.\n");
        break;

    case DIRECTIVE_NO_PARAMS:
        fprintf(stdout, "ERORR.PARAM0X01 : directive must have parameters.\n");

        break;

    case DIRECTIVE_INVALID_NUM_PARAMS:
        fprintf(stdout, "ERORR.PARAM0X02 : illegal number of parameters for a directive.\n");

        break;

    case DATA_COMMAS_IN_A_ROW:
        fprintf(stdout, "ERORR.DATA0X01 : incorrect usage of commas in a .data directive.\n");

        break;

    case DATA_EXPECTED_NUM:
        fprintf(stdout, "ERORR.DATA0X02 : .data expected a numeric parameter.\n");

        break;

    case DATA_EXPECTED_COMMA_AFTER_NUM:
        fprintf(stdout, "ERORR.DATA0X03 : .data expected a comma after a numeric parameter.\n");

        break;

    case DATA_UNEXPECTED_COMMA:
        fprintf(stdout, "ERORR.DATA0X04 : .data got an unexpected comma after the last number.\n");

        break;

    case STRING_TOO_MANY_OPERANDS:
        fprintf(stdout, "ERORR.STRING0X01 : .string must contain exactly one parameter.\n");

        break;

    case STRING_OPERAND_NOT_VALID:
        fprintf(stdout, "ERORR.STRING0X02 : .string operand is invalid.\n");

        break;

    case STRUCT_EXPECTED_STRING:
        fprintf(stdout, "ERORR.STRUCT0X01 : .struct first parameter must be a number.\n");

        break;

    case STRUCT_INVALID_STRING:
        fprintf(stdout, "ERORR.STRUCT0X02 : .struct must have 2 parameters.\n");

        break;

    case EXPECTED_COMMA_BETWEEN_OPERANDS:
        fprintf(stdout, "ERORR.STRUCT0X03 : .struct second parameter is not a string.\n");

        break;

    case STRUCT_INVALID_NUM:
        fprintf(stdout, "ERORR.STRUCT0X04 : .struct must not have more than 2 operands.\n");

        break;

    case STRUCT_TOO_MANY_OPERANDS:
        fprintf(stdout, "ERORR.STRUCT0X05 :.struct must have 2 operands with a comma between them.\n");

        break;

    case EXTERN_NO_LABEL:
        fprintf(stdout, "ERORR.EXTERN0X01 : .extern directive must be followed by a label.\n");

        break;

    case EXTERN_INVALID_LABEL:
        fprintf(stdout, "ERORR.EXTERN0X02 : .extern directive received an invalid label.\n");

        break;

    case EXTERN_TOO_MANY_OPERANDS:
        fprintf(stdout, "ERORR.EXTERN0X02 : .extern must only have one operand that is a label.\n");

        break;

    case COMMAND_NOT_FOUND:
        fprintf(stdout, "ERORR.COMMAND0X01 : invalid command or directive.\n");

        break;

    case COMMAND_UNEXPECTED_CHAR:
        fprintf(stdout, "ERORR.COMMAND0X02 :invalid syntax of a command.\n");

        break;

    case COMMAND_TOO_MANY_OPERANDS:
        fprintf(stdout, "ERORR.COMMAND0X03 :command can't have more than 2 operands.\n");

        break;

    case COMMAND_INVALID_METHOD:
        fprintf(stdout, "ERORR.COMMAND0X04 : operand has invalid addressing method.\n");

        break;

    case COMMAND_INVALID_NUMBER_OF_OPERANDS:
        fprintf(stdout, "ERORR.COMMAND0X05 : number of operands does not match command requirements.\n");

        break;

    case COMMAND_INVALID_OPERANDS_METHODS:
        fprintf(stdout, "ERORR.COMMAND0X06 : operands' addressing methods do not match command requirements.\n");

        break;

    case ENTRY_LABEL_DOES_NOT_EXIST:
        fprintf(stdout, "ERORR.ENTRY0X01 : .entry directive must be followed by an existing label.\n");

        break;

    case ENTRY_CANT_BE_EXTERN:
        fprintf(stdout, "ERORR.ENTRY0X02 : .entry can't apply to a label that was defined as external.\n");

        break;

    case COMMAND_LABEL_DOES_NOT_EXIST:
        fprintf(stdout, "ERORR.LABEL0X08 : label does not exist.\n");

        break;

    case CANNOT_OPEN_FILE:
        fprintf(stdout, "ERORR.FILE0X01 : there was an error while trying to open the requested file.\n");
        break;

    case NOT_ENOUGH_ARGUMENTS:
        fprintf(stdout, "ERORR.FILE0X02 : Not enough arguments,\ncommand line should be like this: ./assembler file1 file2 .. \n");
        break;

    }
}
