# include <stdio.h>
# include <stdlib.h>


char *new_file(int argc ,char* argv);

void check_if_register (char *reg);

char *skipTheSpaces(char *c);



char *getNextWord(char *word);

int ignore_tokens(char *strRow);

int end_line(char *line);

/**void line_hendalre(char *ch, char *line);**/

int find_input_command(char *command);

char *next_command(char *word, char * line);

boolean if_label_exists(char *strRow , int check);

char *next_word (char *word);

labelPointer add_label(labelPointer *table , char *labelName ,unsigned int address);

boolean if_existing_label(labelPointer h, char *labelName);

labelPtr get_label(labelPointer label, char *labelNamee);

int find_directive(char *str);

char *next_list_word(char *word, char *line);

boolean is_number(char *value);

int delete_label_form_table(labelPtr *table, char *name);

boolean serch_if_label_exist(labelPtr labelP, char *name);

unsigned int serch_for_label_address(labelPtr labelP, char *name);

boolean if_label_is_extrnal(labelPtr labelP ,char *name);

void errors(int error, int line);
