#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>


#include "global_commannds.h"
#include "code.h"


void offset_address(labelPtr labelPtr, int address ,boolean data_label);

/**
 * @brief this function handel the first read of the assembly (the algoretam was take from the maman book)
 * 
 * @param file 
 * @param file_name 
 */

void first_read (FILE *file ,char *file_name)
{
    int counetr_line = 1;
    char line[LENGTH_OF_LABEL]; 
    instruction_counter = 0; 
    data_counter = 0;   
    boolean error;  
    boolean is_error = FALSE;  
    
    while(fgets(line,LENGTH_OF_LABEL,file)!=NULL)
    {
        error = 0;
        if(ignore_tokens(line));
            error = read_line_by_line_from_file(line,counetr_line);
    if(error)
    {
        
        errors(error , data_counter);/** <-- **/
        is_error = TRUE;
    }
    data_counter++;
}

if(!error)
    printf("No errors in this point\n");
else
{
    printf("error found, the program will exit now!\n");
    exit(1);
}
    offset_address(symbol_table , MEMORY_START , FALSE);
    offset_address(symbol_table, instruction_counter + MEMORY_START , TRUE);
}


/********************************************************************************/



void offset_address(labelPtr ptr, int address ,boolean data_label)
{
    boolean external= FALSE , action = FALSE;
    while(ptr)
    {
        if(!(ptr->external) && (data_label^(ptr->action)))
        {
            ptr->address += address;
        }
        ptr=ptr->next;
    }
}


/********************************************************************************/

/**
 * @brief this function read line by line from file
 * 
 * @param rowStr the line 
 * @param current_row 
 * @return int 
 */

int read_line_by_line_from_file(char* rowStr , int current_row)
{

int directive_type = UNKNOWN_DIRECTIVE;
int command_type = UNKNOWN_COMMAND;
labelPtr create_label = NULL;
char current_word[LENGTH_OF_LINE];
int counter_of_lable;
boolean lebal = FALSE;

rowStr = skipTheSpaces(rowStr);
if(end_line(rowStr)) 
{
    return 0;
}
if(isalpha(*rowStr) && *rowStr != '.')
{
    return SYNTAX_ERROR;
}
line_hendalre(current_word, rowStr);
counter_of_lable = if_label_exists(current_word , TRUE);
if(counter_of_lable)
{
    if(counter_of_lable > 1)
    {
        return counter_of_lable;
    }  
    else 
    {
    create_label = add_label(&symbol_table , current_word ,0);
    if(!create_label)
        return LABEL_ALREADY_EXISTS;
    rowStr = next_word(rowStr);
    if(end_line(rowStr)){

        return LABEL_ONLY;;
            }
        }
    }
}
line_hendalre(current_word , rowStr);

if(((directive_type = find_directive(current_word)) != -1))
    {
        if(counter_of_lable)
        {
            if(directive_type == EXTERN || dir_type == ENTRY)
	{ 
                delete_label_form_table(&symbols_table, create_label->name);
                label = FALSE;
                counter_of_lable = 0;
            }
            else
            {
                create_label -> address = data_counter; 
            }
    rowStr = next_word(line);
        errors = handle_directive(directive_type, rowStr);
        if (errors)
            return errors;
    }

return 0;
}
/********************************************************************************/

/**
 * @brief this function  handles the directives
 * 
 * @param directive_type 
 * @param line 
 * @return int 
 */

int parse_directive(int directive_type, char *line)
{
    if (!line || end_line(line))
    {
        return DIRECTIVE_NO_PARAMS;
    }

switch (directive_type)
    {
    case DATA:
       
        return data_directive_parse(line);

    case STRING:
        
        return string_directive_parse(line);

    case STRUCT:
       
        return struct_directive_parse(line);

    case ENTRY:
        
        if (!end_line(next_word(line))) 
	{
            return DIRECTIVE_INVALID_NUM_PARAMS;
        }
        break;

    case EXTERN:
        
        return extern_directive_parse(line);
    }
    return 0;
}


/********************************************************************************/

/**
 * @brief this function check the data directive and adds it to the memory
 * 
 * @param line 
 * @return int 
 */

int data_directive_parse(char *line)
{


    char temp[32]; 
   
    boolean number = FALSE, command = FALSE;

    while(!end_line(line))
    {
        line = next_list_word(temp, line); 

        if(strlen(temp) > 0) 
        {
            if (!number) { 
                if (!is_number(temp)) {
                    return DATA_EXPECTED_NUM;
                }

                else {
                    number = TRUE; 
                    command = FALSE; 
                    data[data_counter++] = (unsigned int)atoi(temp); /** data? **/
                }
            }

            else if (*temp != ',') 
            {
                return DATA_EXPECTED_COMMA_AFTER_NUM;
            }

            else 
            {
                if(command) {
                    return DATA_COMMAS_IN_A_ROW;
                }
                else {
                    command = TRUE;
                    number = FALSE;
                }
            }

        }
    }
    if(command == TRUE)
    {
        return DATA_UNEXPECTED_COMMA;
     
    }
    return 0;
}


/********************************************************************************/

/**
 * @brief  this function check the string directive and adds it to the memory
 * 
 * @param line 
 * @return int 
 */

int string_directive_parse(char *line)
{
    char row[LENGTH_OF_LINE];

    line = next_word(line);
    if(!end_line(row) && is_string(row)) { 
        line = skipTheSpaces(line);
        if(end_line(line)) 
        {
            row[strlen(row) - 1] = '\0';
            string_to_data(row + 1);
        }
        else 
        {
            return STRING_TOO_MANY_OPERANDS;
        }
    }
    else 
    {
        return STRING_OPERAND_NOT_VALID;
    }
    return 0;
}


/********************************************************************************/

/**
 * @brief this function wirtes the text and add to the memory
 * 
 * @param labelPtr 
 * @param address 
 * @param data_label 
 */

void string_to_data(char *line)
{
    while (!end_line(line))
    {
        data[data_counter++] = (unsigned int)*line;
        line++;
    }
    data[data_counter++] = '\0';
}


/********************************************************************************/

/**
 * @brief this function check the data struct and adds it to the memory
 * 
 * @param line 
 * @return int 
 */

int struct_directive_parse(char *line)
{
    char temp[LENGTH_OF_LINE];
    line = next_list_word(temp, line);

    if (end_line(temp) || !is_number(temp))
        return STRUCT_INVALID_NUM;
    data[data_counter++] = (unsigned int)atoi(temp);
    line = next_list_word(temp, line);
    if (!end_line(line) && *temp == ',')
    {
        line = next_list_word(temp, line); 
        if (end_line(temp))
            return STRUCT_EXPECTED_STRING;
        else
        {
            if (temp[0] != '"' && temp[strlen(temp) - 1] != '"')
                return STRUCT_INVALID_STRING;
            
            temp[strlen(temp) - 1] = '\0';
            string_to_data(temp + 1);
        }
    }
    else
    {
        return EXPECTED_COMMA_BETWEEN_OPERANDS;
    }
    line = next_word(line);
    if (!end_line(line))
        return STRUCT_TOO_MANY_OPERANDS;
    return 0;
}


/********************************************************************************/

/**
 * @brief this function check the extern directive and adds it to the memory
 * 
 * @param line 
 * @return int 
 */

int extern_directive_parse(char *line)
{
    char word[LENGTH_OF_LABEL]; 
     labelPtr new = NULL;

    line_hendalre(word, line);
    if(end_line(word)) 
    {
        return EXTERN_NO_LABEL;
        
    }
    if(!if_label_exists(word, FALSE)) 
    {
        return EXTERN_INVALID_LABEL;
    }

    line = next_word(line);
    if(!end_line(line))
    {
        return EXTERN_TOO_MANY_OPERANDS;
    }

   line_hendalre(word, line);
    new = add_label(&symbols_table, word, 0);
    if (!new)
        return 1;
    is_extern = TRUE;
    new->external = TRUE;
    return 0;
   
}


/********************************************************************************/

/**
 * @brief this function handles the right command
 * 
 * @param command_type 
 * @param line 
 * @return int 
 */

int handle_command(char command_type , int *line)
{
    boolean is_first = FALSE , is_second = FALSE;
    int first_method = 0 , second_method = 0;
    char first_op[20] , second_op[20];
    unsigned int word;

    line = next_command(first_op , line);
    if(!end_line(second_op))
    {
        if(second_op[0] != ','){
            return COMMAND_UNEXPECTED_CHAR;
        }
        else{
            line = next_command(second_op, line);
            if(end_line(second_op)){
                return COMMAND_UNEXPECTED_CHAR;
                }
                is_second = TRUE;
            }
        }
    
    line = skipTheSpaces(line);
    if(!end_line(line))
    {
        return COMMAND_TOO_MANY_OPERANDS;
    }
    if(is_first)
    {
        first_method = detect_method(first_op);
    }
    if(is_second){
        second_method = detect_method(second_op);
    }
        if(command_num_operands(command_type , is_first, is_second)) 
        {
            if(command_methods(command_type , first_method, second_method)) 
            {
                word = str_to_bits(command_type , is_first, is_second, first_method, second_method);
                write_instructions(word);
                instruction_counter += counts_command_num(is_first, is_second, first_method, second_method);
            }

            else
            {
                return COMMAND_INVALID_OPERANDS_METHODS;
            }
        }
        else
        {
            return COMMAND_INVALID_NUMBER_OF_OPERANDS;
        }
    }

/********************************************************************************/

/**
 * @brief this function check the type of the instructions
 * 
 * @param operand 
 * @return int 
 */

int detect_method(char *operand)
{
    char *temp; 

    if(end_line(operand)) return -1;

    if (*operand == '#') { 
        operand++;
        if (is_number(operand))
            return IMMEDIATE_ADDRESS;
    }

    else if (check_if_register(operand))
        return REGISTER_ADDRESS;


    else if (if_label_exists(operand, FALSE)) 
        return DIRECT_ADDRESS;

    else if (if_label_exists(strtok(operand, "."), FALSE)) { 
        operand = strtok(NULL, ""); 
        if (strlen(temp) == 1 && (*temp == '1' || 
                *temp == '2'))
            return STRUCT_ADDRESS;
    }
    return COMMAND_INVALID_METHOD;
}


/********************************************************************************/

/**
 * @brief this function check the command if it the right mathces the operand
 * 
 * @param type 
 * @param first 
 * @param second 
 * @return boolean 
 */

boolean command_num_operands(int type, boolean first, boolean second)
{
    switch (type)
    {
        
        case MOV:
        case CMP:
        case ADD:
        case SUB:
        case LEA:
            return first && second;
        case CLR:
        case NOT:
        case INC:
        case DEC:
        case JMP:
        case BNE:
        case JSR:
        case RED:
        case PRN:
            return first && !second;
        case RTS:
        case HLT:
            return !first && !second;
    }
    return FALSE;
}


/********************************************************************************/

/**
 * @brief this command check the commmands method type
 * 
 * @param type 
 * @param first_method 
 * @param second_method 
 * @return boolean 
 */

boolean command_methods(int type, int first_method, int second_method)
{
    switch (type)
    {
        case MOV:
        case ADD:
        case SUB:
            return (first_method == IMMEDIATE_ADDRESS ||
                    first_method == DIRECT_ADDRESS ||
                    first_method == REGISTER_ADDRESS)
                   &&
                   (second_method == DIRECT_ADDRESS ||
                    second_method == REGISTER_ADDRESS);
        case CMP:
            return (first_method == IMMEDIATE_ADDRESS ||
                    first_method == DIRECT_ADDRESS ||
                    first_method == REGISTER_ADDRESS)
                   &&
                   (second_method == IMMEDIATE_ADDRESS ||
                    second_method == DIRECT_ADDRESS ||
                    second_method == REGISTER_ADDRESS);
        case LEA:
            return (first_method == DIRECT_ADDRESS)
                   &&
                   (second_method == DIRECT_ADDRESS ||
                    second_method == REGISTER_ADDRESS);
        case CLR:
        case NOT:
        case INC:
        case DEC:
        case RED:
            return first_method == DIRECT_ADDRESS ||
                   first_method == REGISTER_ADDRESS;
        case JMP:
        case BNE:
        case JSR:
            return first_method == DIRECT_ADDRESS;
        case PRN:
            return first_method == IMMEDIATE_ADDRESS ||
                   first_method == DIRECT_ADDRESS ||
                   first_method == REGISTER_ADDRESS;
        case RTS:
        case HLT:
            return TRUE;
    }
    return FALSE;
}


/********************************************************************************/

/**
 * @brief this function create an num and insert it to the memory
 * 
 * @param method_type 
 * @param first_op 
 * @param second_op 
 * @param first_method 
 * @param second_method 
 * @return unsigned int 
 */

unsigned int str_to_bits(int method_type, boolean first_op , boolean second_op, int first_method, int second_method)
{
    unsigned int str_in_bits = method_type;
    str_in_bits <<= METHOD_BITS; 

    if (first_op && second_op)
    {
        str_in_bits |= first_method;
        str_in_bits <<= METHOD_BITS;
        str_in_bits |= second_method;
    }
    else if (second_op)
    {
        str_in_bits <<= METHOD_BITS;
        str_in_bits |= second_method;
    }
    else {
        str_in_bits <<= METHOD_BITS;

    }
    str_in_bits = add_are_op(str_in_bits, ABSOLUTE_CODE);
    return str_in_bits;
}


/********************************************************************************/

/**
 * @brief this function adds the AREA operation
 * 
 * @param word 
 * @param are 
 * @return unsigned int 
 */

unsigned int add_are_op(unsigned int word, int are)
{
    return (word << 2) | are;
}


/********************************************************************************/



void write_instructions(unsigned int word)
{
    instructions[instruction_counter++] = word;
}


/********************************************************************************/

/**
 * @brief this function counts the number of instructions and add it to the memory 
 * 
 * @param first 
 * @param second 
 * @param first_method 
 * @param second_method 
 * @return int 
 */

int counts_command_num(int first , int second ,  int first_method , int second_method)
{
    int counter = 0;
    if(first) counter += word_counter(first_method);
    if(second) counter += word_counter(second_method);

    if(first && second && first_method && second_method == REGISTER_ADDRESS && second_method == REGISTER_ADDRESS) counter --;

    return counter;
}
