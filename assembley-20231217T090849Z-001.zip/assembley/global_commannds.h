#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>


/********************************************************************************/

#define LENGTH_OF_LINE 82
#define LENGTH_OF_LABEL 30
#define COMMANDS_LIST 16
#define SPECIALSYMBOLS 32
#define MACHINEBITS 10
#define BIT2HEZKA5 5
#define MAXMACRO 10
#define MAXRONAMESIZE 30
#define WORD 10
#define OPCODE 4
#define METHOD_BITS 2
#define ARE 2
#define REGISTER 4
#define ADDRESS 8
#define REGISTER_LEN 2
#define COMMANDS_LEN 3
#define FIRST_REGISTER 0
#define LAST_REGISTER 7
#define ARE 2
#define TABLE_COMMAND_LEN 3
#define MEMORY_START 100



/********************************************************************************/

typedef enum boolean{
    FALSE , TRUE 
}boolean;

typedef struct structLabels * labelPtr;
typedef struct  structLabels {
	    char labelName[LENGTH_OF_LABEL]; 
    unsigned int address;
    boolean entry; 
    boolean external; 
    boolean action; 
	    labelPtr next; 
}labelPointer;

extern int instruction_counter,data_counter;
extern labelPointer symbols_table;
extern externPointer external_list;
extern labelPtr symbol_table;
extern boolean is_extern;
extern int found_code_error;
extern boolean entry_existence , extern_existence;

/********************************************************************************/


typedef struct ext * externPointer;
typedef struct ext {
    char labelName[LENGTH_OF_LABEL];
    unsigned int address; 
    externPointer next; 
    externPointer prev; 
}ext;


/********************************************************************************/


/**typedef enum isMacro {
    FALSE = 0, 
    TRURE = 1;
}boolean;**/



/********************************************************************************/

enum opcodes {MOV , CMP , ADD ,SUB,  SUM , NOT, CLR , LEA , INC , DEC , JMP , BNE , GET , PRN , JSR , RED , RTS , HLT , UNKNOWN_COMMAND}; /** for switc case in fuction command_num_operands**/
enum AREOP {ABSOLUTE_CODE ,EXTERNAL_CODE ,REALOCTION_CODE , UNKNOWN_TYPE};
enum FILES {F_EXTERN , F_MACRO , F_INPUT , F_ENTRY , F_OBJECT};
enum address {IMMEDIATE_ADDRESS,DIRECT_ADDRESS,STRUCT_ADDRESS,REGISTER_ADDRESS , UNKNOWN_ADDRESS};
enum directives {DATA , STRING , ENTRY , EXTERN , STRUCT , UNKNOWN_DIRECTIVE};
enum errors {SYNTAX_ERROR = 1,LABEL_ALREADY_EXISTS ,LABEL_TOO_LONG ,
    LABEL_INVALID_FIRST_CHAR ,LABEL_ONLY_ALPHANUMERIC ,LABEL_CANT_BE_COMMAND ,
    LABEL_ONLY ,LABEL_CANT_BE_REGISTER ,DIRECTIVE_NO_PARAMS ,
    DIRECTIVE_INVALID_NUM_PARAMS ,DATA_COMMAS_IN_A_ROW ,
    DATA_EXPECTED_NUM ,DATA_EXPECTED_COMMA_AFTER_NUM ,DATA_UNEXPECTED_COMMA ,
    STRING_TOO_MANY_OPERANDS ,STRING_OPERAND_NOT_VALID ,STRUCT_EXPECTED_STRING ,
    STRUCT_INVALID_STRING ,EXPECTED_COMMA_BETWEEN_OPERANDS ,STRUCT_INVALID_NUM ,
    STRUCT_TOO_MANY_OPERANDS ,EXTERN_NO_LABEL ,EXTERN_INVALID_LABEL ,EXTERN_TOO_MANY_OPERANDS ,
    COMMAND_NOT_FOUND ,COMMAND_UNEXPECTED_CHAR ,COMMAND_TOO_MANY_OPERANDS ,COMMAND_INVALID_METHOD ,
    COMMAND_INVALID_NUMBER_OF_OPERANDS ,COMMAND_INVALID_OPERANDS_METHODS ,ENTRY_LABEL_DOES_NOT_EXIST ,
    ENTRY_CANT_BE_EXTERN ,COMMAND_LABEL_DOES_NOT_EXIST ,CANNOT_OPEN_FILE ,NOT_ENOUGH_ARGUMENTS };




/**typedef enum {
    Finput,
    Fmacro,
    Fobject,
    Fentry,
    Fextern
}directiveLines;**/


/********************************************************************************/

const char special32base[SPECIALSYMBOLS] = {'!','@','#','$','%','^','&','*','<','>','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v'};

const char *guidanceSentences[] = {".data",".string",".entry",".extern",".struct"};

const char *opcodes[] = {"mov","cmp","add","sub","not","clr","lea","inc","dec","jmp","bne","get","prn","jsr","rts","hlt"};


const char *addressingMethods[4] = {"IMMEDIATE_ADDRESS","DIRECT_ADDRESS","STRUCT_ADDRESS","REGISTER_ADDRESS"}; 



extern const char *guidanceSentences[];
extern const char *opcodes[];
extern unsigned int data[];
extern unsigned instructions[];
/********************************************************************************/


/**typedef enum register{
    r0,
    r1,
    r2,
    r3,
    r4,
    r5,
    r6,
    r7,
    r-1 
}register;**/


/********************************************************************************/



