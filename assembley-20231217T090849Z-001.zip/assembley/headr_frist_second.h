



/****************************************** FIRST READ ******************************************/

void first_read (FILE *file ,char *file_name);

void offset_address (labelPointer labelPtr, int address ,boolean data_label);

int read_line_by_line_from_file(char* rowStr , int current_row);

int parse_directive(int directive_type, char *line);

int data_directive_parse(char *line);

int string_directive_parse(char *line);

void string_to_data(char *line);

int struct_directive_parse(char *line);

int extern_directive_parse(char *line);

int handle_command(char command_type , int *line);

int detect_method(char *operand);

boolean command_num_operands(int type, boolean first, boolean second);

boolean command_methods(int type, int first_method, int second_method);

unsigned int str_to_bits(int method_type, boolean first_op , boolean second_op, int first_method, int second_method);

unsigned int add_are_op(unsigned int word, int are);

void write_instructions(unsigned int word);

int counts_command_num(int first , int second ,  int first_method , int second_method);



/******************************************** SECOND READ *********************************************/



void second_read (FILE *file ,char* cfile_name);

void read_the_second_read_line(char *line , int num);

int command_second_read(int command_type , char *line);

void encode_word_second_read(boolean dest, int method_type, char *op);

unsigned int build_register_word(boolean dest , char* reg);

unsigned int add_are(unsigned int word, int are);

void encode_label(char* label);

int write_output_3_files(char* original);

FILE *open_file(char *filename, int type);

char *create_file_name(char *fileName, int type);

void write_output_entry(FILE *file);

char *convert_to_special_base_32(unsigned int num);

unsigned int move_bits(unsigned int word, int start, int end);

void write_output_extern(FILE *file);

void check_operands(int command_type, boolean *is_src, boolean *is_dest);








