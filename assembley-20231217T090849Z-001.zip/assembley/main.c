
#include <stdio.h>
#include <stdlib.h>

#include "global_commannds.h"
#include "pre_assembler.h"
#include "headr_frist_second.h"
#include "code.h"


int inctrucrion_counter;
int data_counter;
boolean error;
labelPointer symbol_table;
externPointer extP;
unsigned int data[2000];/**Ram**/
unsigned int instuctions[2000];
void reset();


int main (int argc ,char *argv[])
{

FILE *file;
int i;
char *input_of_file_name;

for(i = 1 ; i < argc ; i++){

	input_of_file_name = new_file(argv[i] , F_INPUT);
	file = fopen(input_of_file_name , "r");
		if(file != NULL)
		{
   	 	reset();
    		printf("\n~~~~~~~~~~~~~ Started assemble read file: %s\n ~~~~~~~~~~~~~\n" ,input_of_file_name);
    		pre_assembler(file, argv[i]);
   		 fclose(file);
		}	
		else {  errors(CANNOT_OPEN_FILE, -1); }
	
		if(file != NULL)
           		{
       			 printf("\n~~~~~~~~~~~~~ Started first read of file: %s\n ~~~~~~~~~~~~~\n" ,input_of_file_name);
        		first_read(file, input_of_file_name);
        		fclose(file);
		
				if(!error)
				{	
   					printf("\n~~~~~~~~~~~~~ Started first read of file: %s\n ~~~~~~~~~~~~~\n" ,input_of_file_name);
    					rewind(file);
   					second_read(file,input_of_file_name);
					}
					printf("\n~~~~~~~~~~~~~ Finished %s assembling: %s\n ~~~~~~~~~~~~~\n" ,input_of_file_name);
				}
		else
            		{
           	     		errors(CANNOT_OPEN_FILE, -1);
				free(input_of_file_name);
				fclose(file);
				
            		}   
        						/**else
        						{
          							 errors(NOT_ENOUGH_ARGUMENTS, -1);
    
    								return 0;
 							}**/
		}
				return 0;
}


/********************************************************************************/


/**void reset()
{
    symbols_table = NULL;
    external_list = NULL;
    has_entry = FALSE;
    has_extern = FALSE;
    error_exists = FALSE;
}**/
