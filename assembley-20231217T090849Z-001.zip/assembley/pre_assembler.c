
#include "global_commannds.h"
#include "pre_assembler.h"


static macro * macro_head = NULL;
macro *add_macro(char *macro_name)
{
    macro *new = NULL;
    if((new = get_macro(macro_name)))
   {
        fprintf(stderr, "ERROR! : cannot add new macro, macro already exist\n");
        return NULL;
    }

    new = malloc(sizeof(macro));
    if (new == NULL){
        fprintf(stderr,"ERROR! : could not allocate memory ");
        exit(1);
    }

    new->macro_name = malloc(sizeof (char )*LENGTH_OF_LINE);
    strcpy(new->macro_name,macro_name);

    new->macro_code = (char *)malloc(sizeof (char )*LENGTH_OF_LINE * 6);
    new->macro_code[0] = '\0';
    new->next = NULL;
    if(!macro_head){
        macro_head = new;
    } else {
        macro *ptr = macro_head;
        while (ptr->next){
            ptr = ptr->next;
        }
        ptr->next = new;
    }
    return new;
}



/********************************************************************************/


macro *get_macro(char *macro_name){
    macro *ptr = macro_head;
    while (ptr){
        if (!strcmp(ptr->macro_name,macro_name)){
            return ptr;
        }
        ptr = ptr->next;
    }
    return NULL;
}


/********************************************************************************/

void print_macro_list() 
{
   macro* ptr;
    for (ptr = macro_head; ptr != NULL; ptr = ptr->next)
        printf("macro: %s\nmacro code: %s \n", ptr->macro_name, ptr->macro_code);
}


/********************************************************************************/
/**
 * function that free the macro list.
 * */

void free_macro_list() {
    macro *list = macro_head, *temp;

    while (list != NULL) {
        temp = list;
        list = list->next;
        free(temp->macro_name);
        free(temp->macro_code);
        free(temp);
    }
    macro_head = NULL;
}


/********************************************************************************/



void pre_assembler (FILE *file_r, char *file_name)
{ 
    FILE *file_w;
    /**char *rows = row;
    /**char word[LENGTH_OF_LINE];**/
    char line[LENGTH_OF_LINE]; 
    char line_cpy[LENGTH_OF_LINE]; 
    char *word= NULL; 
    macro *macroPtr = NULL; 
    int macro_flag = 0;
    int line_counter = 1;
    

    file_w = new_file(file_name , ".am" ,"w");
    if (!file_w)
	fprintf(stderr ," can now create file %s.am");
      exit(1);


while(fgets(line , LENGTH_OF_LINE ,file_r))
{
 
  strcpy(line_cpy , line);
  word = strtok(line_cpy ,"\t\n");
  if(macro_flag){
    if(strcmp(word, "endmacro")){ /** the function reads and compers to the word 'endmacro'**/
      strcat(macroPtr->macro_code ,line);
      continue;
    }
    else{
      macro_flag = 0;
      macroPtr = NULL;
      continue;
    }
  }
  //**line = skipTheSpaces(line);**/
 /**if(isLabel(word)){
  *   line = strtok(line, "\t\n");
  * }**/

 if(!strcmp(word , "macro")){
    word = strtok (NULL,"\t\n");
    if(!word){
    fprinft(stderr,"ERORR.MACRO! : NO MACRO NAME , MACRO NEEDS TO HAVE A NAME!");
      return;
 }
  else if(!(macroPtr = add_macro(word))){
    return;
  }else {macro_flag = 1;}
    macro *mac = NULL;
    if (!(mac = get_macro(word)))
    {
      fputs(line ,file_w);
    }
	else 
	{
	fputs(mac->macro_code ,file_w);
	}
   }
}
fcolse(file_w);
freeList();

	}



