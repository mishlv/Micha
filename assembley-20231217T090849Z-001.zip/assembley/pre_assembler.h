#include <stdlib.h>
#include <stdio.h>
#include <string.h>


typedef struct str_Macro * macroPointer;
typedef struct macro {
    char *macro_name;
    char *macro_code;
    struct macro * next;
}macro;

macro *add_macro(char *macro);

macro *get_macro(char *macro);

void print_macro_list();

void free_macro_list();

void pre_assembler(FILE *file, char *file_name);
