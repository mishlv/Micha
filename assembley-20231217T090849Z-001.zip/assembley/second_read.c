#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#include "global_commannds.h"
#include "code.h"

/**
 * @brief this function handel the second read of the assembly (the algoretam was take from the maman book)
 * 
 * @param file 
 * @param file_name 
 */


void second_read (FILE *file ,char *file_name)
{
    char line[LENGTH_OF_LINE];
    int counetr = 1;
    boolean is_error = FALSE;
    instruction_counter = 0;

    while(fgets(line , LENGTH_OF_LINE , file) != NULL)
    {
        found_code_error = 0;
        if(!ignore_tokens(line))
            read_the_second_read_line(line);
        if(found_code_error)
        {
            write_errors(found_code_error , counetr);
            is_error = TRUE;
            found_code_error = 0;
        }
        counetr ++;
    }
    if(!is_error)
    wirte_3_files(file_name);
    
    free_label(&symbol_table);
    free_ext(&external_list);

}


/********************************************************************************/

/**
 * @brief this function read line by line from file
 * 
 * @param line 
 * @param num 
 */

void read_the_second_read_line(char *line , int num)
{
    char curr_word[LENGTH_OF_LINE];
    int command_type ,directive_type;
    int counetr;

    line = skipTheSpaces(line);
    if(end_line(line)) return 0;
    line_hendalre(curr_word,line);
    if(check_label_declaration(curr_word))
    {
        line = next_word(line);
        line_hendalre(curr_word , line);
    }
    if(((directive_type = find_directive(curr_word)) != -1))
   {
        line = next_word(line);
        if(directive_type == ENTRY) /** ENTRY **/
        {
        line_hendalre(curr_word, line);
        add_entry(symbol_table , curr_word);
        }
    }
    else if((command_type = find_input_command(curr_word)) != -1))
    {
        line = next_word(line);
        command_second_read(command_type , line);
    }
}


/********************************************************************************/

/**
 * @brief this function will encode words that was not encode in the first read of the assembly
 * 
 * @param command_type 
 * @param line 
 * @return int 
 */

int command_second_read(int command_type , char *line)
{
    char first_op[LENGTH_OF_LINE] ,second_op[LENGTH_OF_LINE];
    char *sourse = first_op, *dest = second_op;
    boolean src = FALSE , dst = FALSE;
    int sourse_method = UNKNOWN_ADDRESS , dest_method = UNKNOWN_ADDRESS;
    

   check_if_operands_exsit(command_type, &src, &dest);
    if (src)
        sourse_method = (instructions[instruction_counter], 4, 5);
    if (dest)
        dest_method = bits(instructions[instruction_counter], 2, 3);
    if (src || dest)
    {
        line = next_command(first_op, line);
        if (src && dest)
        { 
            line = next_command(second_op, line);
           next_command(second_op, line); 
        }
        else
        { 
            dest = first_op;
            src = NULL;
        }
    }
    instruction_counter++;                                   
    if (sourse && dst && sourse_method == REGISTER_ADDRESS && dest_method == REGISTER_ADDRESS)
    { /
        unsigned int word = build_reg(FALSE, sourse) | build_reg(TRUE, dest);
        instructions[instruction_counter++] = word;
    }
    else
    {
        if (src)
            encode_word_second_read(FALSE, sourse_method, sourse);
        if (dest)
            encode_word_second_read(TRUE, dest_method, dest);
    }
}


/********************************************************************************/

/**
 * @brief this function encode word to memory
 * 
 * @param dest 
 * @param method_type 
 * @param operand 
 */

void encode_word_second_read(boolean dest, int method_type, char *operand)
{
     unsigned int word = EMPTY_WORD;; 
     char *temp;

    switch (method)
    {

        case METHOD_REGISTER:
            word = build_register_word(dest, operand);
            instruction[instruction_counter++] = word;


        case METHOD_IMMEDIATE: 
            word = (unsigned int) atoi(operand + 1);
            word = add_are(word, ABSOLUTE_CODE);
            instruction[instruction_counter++] = word;
            break;

         case METHOD_DIRECT:
            encode_label(operand);
            break;

        case METHOD_STRUCT: 
            temp = strchr(operand, '.');
            *temp = '\0';
            encode_label(operand); 
            *temp++ = '.';
            word = (unsigned int) atoi(temp);
            word = insert_are(word, ABSOLUTE_CODE);
            instruction[instruction_counter++] = word; 
        break;

    }
}

/********************************************************************************/


unsigned int build_register_word(boolean dest , char *reg)
{
    unsigned int word = (unsigned int)atoi(register + 1); 

    if (!dest) 
        word <<= 4;
    word = add_are(word, ABSOLUTE_CODE);
    return word;
}  


/********************************************************************************/

/**
 * @brief this function add ARE
 * 
 * @param word 
 * @param are 
 * @return unsigned int 
 */

unsigned int add_are(unsigned int word, int are)
{
    return (word << 2) | are;

}


/********************************************************************************/

/**
 * @brief this function add label to the memory
 * 
 * @param label 
 */

void encode_label(char *label)
{
    unsigned int word;

    if (serch_if_label_exist(symbols_table, label))
    { 
        word = serch_for_label_address(symbols_table, label);

        if (if_label_is_extrnal(symbols_table, label))
        {
           add_external_list(&external_list, label, instruction_counter + MEMORY_START);
            word = add_are(word, EXTERNAL_CODE);
        }
        else
            word = add_are(word, REALOCTION_CODE);

        instructions[instruction_counter++] = word;
    }
    else
    {
        instruction_counter++;
        errors = COMMAND_LABEL_DOES_NOT_EXIST;
    }
}

/********************************************************************************/

/**
 * @brief this function wirte output the 3 files 
 * 
 * @param original 
 * @return int 
 */

int write_output_3_files(char *original)
{
    FILE *file;

    file = open_file(original, F_OBJECT);
    write_output_ob(file);
    printf("Output file at %s%s\n", original,".ob");
    if(entry_existence) {  
        file = open_file(original, F_ENTRY);
        write_output_entry(file);
        printf("Output file at %s%s\n", original,".ent");
    }
    if(extern_existence) 
    {
        file = open_file(original, F_EXTERN);
        write_output_extern(file);
        printf("Output file at %s%s\n", original,".ent");
    }

    return 0;
}


/********************************************************************************/

/**
 * @brief this function are craete new file
 * 
 * @param filename 
 * @param type 
 * @return FILE* 
 */

FILE *open_file(char *filename, int type)
{
    FILE *file;
    filename = new_file(filename, type); 
    file = fopen(filename, "w"); 
    free(filename);              
    if (file == NULL)
    {
        printf("ERROR! CANNOT OPEN FILE");
        return NULL;
    }
    return file;
}


/********************************************************************************/


/**
 * @brief this function write the .ent file
 * 
 * @param file 
 */
void write_output_entry(FILE *file)
{
    char *param1 = convert_to_special_base_32(instruction_counter), *param2 = convert_to_special_base_32(data_counter);
    unsigned int address = MEMORY_START;
    int i;

    fprintf(file, "m\tf\n\n");
    free(param1);
    free(param2);

    for (i = 0; i < instruction_counter; address++, i++) 
    {
        param1 = convert_to_special_base_32(address);
        param2 = convert_to_special_base_32(instructions[i]);

        fprintf(file, "%s\t%s\n", param1, param2);

        free(param1);
        free(param2);
    }

    for (i = 0; i < data_counter; address++, i++) 
    {
        param1 = convert_to_special_base_32(address);
        param2 = convert_to_special_base_32(data[i]);

        fprintf(file, "%s\t%s\n", param1, param2);

        free(param1);
        free(param2);
    }

    fclose(file);
}


/********************************************************************************/

/**
 * @brief this function convert to special base 32
 * 
 * @param num 
 * @return char
 */

char *convert_to_special_base_32(unsigned int num)
{                                         
    char *spec_base32= (char *) malloc(3);

    spec_base32[0] = spec_base32[move_bits(num, 5, 9)];
    spec_base32[1] = spec_base32[move_bits(num, 0, 4)];
    spec_base32[2] = '\0';

    return spec_base32;
}


/********************************************************************************/


unsigned int move_bits(unsigned int word, int start, int end){
    
    unsigned int temp;
    int length = end - start + 1; 
    unsigned int mask = (int) pow(2, len) - 1; 

    mask = mask << start;
    temp = word & mask;
    temp = temp >> start;

    return temp;
    
}


/********************************************************************************/

/**
 * @brief this function write the .ext file
 * 
 * @param file 
 */

void write_output_extern(FILE *file)
{
    
    char *base32;
    externPointer node = external_list;
    do
    {
        base32 = convert_to_special_base_32(node->address);
        fprintf(file, "%s\t%s\n", node-> labelName, base32_address); 
        free(base32);
        node = node->next;

    } while (node !=  external_list);
    fclose(file);
}


/********************************************************************************/

/**
 * @brief this function checks the commands
 * 
 * @param command_type 
 * @param sourse 
 * @param dest 
 */
void check_operands(int command_type, boolean *sourse, boolean *dest)
{
    switch (command_type)
    {
        case MOV:
        case CMP:
        case ADD:
        case SUB:
        case LEA:
            *sourse = TRUE;
            *dest = TRUE;
            break;
        case NOT:
        case CLR:
        case INC:
        case DEC:
        case JMP:
        case BNE:
        case GET:
        case PRN:
        case JSR:
            *sourse = FALSE;
            *dest = TRUE;
            break;
        case RTS:
        case HLT:
            *sourse = FALSE;
            *dest = FALSE;
    }
}
